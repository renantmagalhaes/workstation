# i3

## Inspirations
https://github.com/adi1090x/polybar-themes

## Configurations

- [Keybindings](https://i3wm.org/docs/userguide.html#_default_keybindings) 