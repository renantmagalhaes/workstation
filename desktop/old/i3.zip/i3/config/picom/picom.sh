
#!/bin/bash
picom --experimental-backend
